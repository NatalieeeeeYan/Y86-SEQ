Y86-Assembler
=============

A quick hacked together Y86 assembler written in python.